#!/bin/bash

function compile_lammps
{
rm -rf ./src/Obj_mpi ./src/lmp_mpi lmp_mpi

savefiles ""
tes=`which mpirun`

if [ -z $tes ]; then
    module add mpich
fi

cd src/
make yes-misc
make yes-rigid
make -j 4 mpi
cp lmp_mpi ./..
cd ..
}

compile_lammps
