/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

#include <iostream>

#include "math.h"
#include "stdlib.h"
#include "pair_cosatt.h"
#include "atom.h"
#include "force.h"
#include "comm.h"
#include "neigh_list.h"
#include "memory.h"
#include "error.h"
#include "math_const.h"

using namespace LAMMPS_NS;
using namespace MathConst;
using std::cout;
using std::endl;

/* ---------------------------------------------------------------------- */

PairCosatt::PairCosatt(LAMMPS *lmp) : Pair(lmp)
{
  writedata = 1;
}

/* ---------------------------------------------------------------------- */

PairCosatt::~PairCosatt()
{
  if (allocated) {
    memory->destroy(setflag);
    memory->destroy(cutsq);

    memory->destroy(rad);
    memory->destroy(r_c);
    memory->destroy(w_c);
    memory->destroy(a);
    memory->destroy(offset);
  }
}

/* ---------------------------------------------------------------------- */

void PairCosatt::compute(int eflag, int vflag)
{
    int i,j,ii,jj,inum,jnum,itype,jtype;
    double xtmp,ytmp,ztmp,delx,dely,delz,evdwl,fpair;
    double rsq,r,rinv,wcinv,rc,argument,factor, coss, sinn;
    int *ilist,*jlist,*numneigh,**firstneigh;

    evdwl = 0.0;
    if (eflag || vflag) ev_setup(eflag,vflag);
    else evflag = vflag_fdotr = 0;

    double **x = atom->x;
    double **f = atom->f;
    int *type = atom->type;
    int nlocal = atom->nlocal;
    double *special_lj = force->special_lj;
    int newton_pair = force->newton_pair;

    inum = list->inum;
    ilist = list->ilist;
    numneigh = list->numneigh;
    firstneigh = list->firstneigh;

    // loop over neighbors of my atoms

    for (ii = 0; ii < inum; ii++) {
        i = ilist[ii];
        xtmp = x[i][0];
        ytmp = x[i][1];
        ztmp = x[i][2];
        itype = type[i];
        jlist = firstneigh[i];
        jnum = numneigh[i];

        for (jj = 0; jj < jnum; jj++) {
            j = jlist[jj];
            factor = special_lj[sbmask(j)];
            j &= NEIGHMASK;

            delx = xtmp - x[j][0];
            dely = ytmp - x[j][1];
            delz = ztmp - x[j][2];
            rsq = delx*delx + dely*dely + delz*delz;
            jtype = type[j];

            //
            //    a[itype][jtype] == epsilon, factor = 1.0
            //

            // parameter check
            /*for(int iii = 0; iii<7; ++iii) {
                for(int jjj = 0; jjj<7; ++jjj) {
                    cout << iii << " " << jjj << " " << a[iii][jjj] << " " << r_c[iii][jjj] << " " << w_c[iii][jjj] << " " << cutsq[iii][jjj] << endl;
                }
            }
            exit(1);*/

            if (rsq <= cutsq[itype ][jtype]) { // rc + wc
                r = sqrt(rsq);
                rinv = 1.0/r;
                wcinv = 1.0/w_c[itype ][jtype];

                argument = MY_PI2*(r-r_c[itype ][jtype])*wcinv;

                sincos(argument, &sinn, &coss);

                fpair = - factor*a[itype ][jtype]*MY_PI*coss*sinn*wcinv*rinv;

                if (eflag) {
                    evdwl =  - factor*a[itype ][jtype]*coss*coss - offset[itype ][jtype];
                    evdwl *= factor; // here evdwl is correct
                }

                if (r < r_c[itype ][jtype]) {
                    fpair = 0.0;
                    if (eflag) {
                        evdwl = - factor*a[itype][jtype];
                    }
                }

                f[i][0] += delx*fpair;
                f[i][1] += dely*fpair;
                f[i][2] += delz*fpair;
                if (newton_pair || j < nlocal) {
                    f[j][0] -= delx*fpair;
                    f[j][1] -= dely*fpair;
                    f[j][2] -= delz*fpair;
                }

                if (evflag)
                    ev_tally(i,j,nlocal,newton_pair, evdwl,0.0,fpair,delx,dely,delz); // doesnt change evdwl
            }

        }
    }
    if (vflag_fdotr) virial_fdotr_compute();
}

  /* ----------------------------------------------------------------------
     allocate all arrays
     ------------------------------------------------------------------------- */

  void PairCosatt::allocate()
  {
    allocated = 1;
    int n = atom->ntypes;

    memory->create(setflag,n+1,n+1,"pair:setflag");
    for (int i = 1; i <= n; i++)
      for (int j = i; j <= n; j++)
        setflag[i][j] = 0;

    memory->create(cutsq,n+1,n+1,"pair:cutsq");

    memory->create(rad,n+1,"pair:rad");
    memory->create(r_c,n+1,n+1,"pair:r_c");
    memory->create(w_c,n+1,n+1,"pair:w_c");
    memory->create(a,n+1,n+1,"pair:a");
    memory->create(offset,n+1,n+1,"pair:offset");
  }

  /* ----------------------------------------------------------------------
     global settings
     ------------------------------------------------------------------------- */

  void PairCosatt::settings(int narg, char **arg)
  {
    if (narg != 2) error->all(FLERR,"Illegal pair_style command");

    wc_global = force->numeric(FLERR,arg[0]);
    rc_global = force->numeric(FLERR,arg[1]);

    // reset cutoffs that have been explicitly set

    if (allocated) {
      int i,j;
      for (i = 1; i <= atom->ntypes; i++)
        for (j = i+1; j <= atom->ntypes; j++) {
          if (setflag[i][j]) r_c[i][j] = rc_global;
          if (setflag[i][j]) w_c[i][j] = wc_global;
        }
    }
  }

  /* ----------------------------------------------------------------------
     set coeffs for one or more type pairs
     ------------------------------------------------------------------------- */

  void PairCosatt::coeff(int narg, char **arg)
  {
    if (narg < 3 || narg > 5)
      error->all(FLERR,"Incorrect args for pair coefficients");
    if (!allocated) allocate();

    int ilo,ihi,jlo,jhi;
    force->bounds(FLERR, arg[0],atom->ntypes,ilo,ihi);
    force->bounds(FLERR, arg[1],atom->ntypes,jlo,jhi);

    double rc_one = rc_global;
    double wc_one = wc_global;

    double a_one = force->numeric(FLERR,arg[2]); // eps
    if (narg >= 4) rc_one = force->numeric(FLERR,arg[3]);
    if (narg == 5) wc_one = force->numeric(FLERR,arg[4]);

    // r_c wrong, w_c right
    cout << ilo << " " << ihi << " " << jlo << " " << jhi << endl;
    cout << a_one << " " << rc_one << " " << wc_one << endl;

    int count = 0;
    for (int i = ilo; i <= ihi; i++) {
      for (int j = MAX(jlo,i); j <= jhi; j++) {
        a[i][j] = a_one;
        r_c[i][j] = rc_one;
        w_c[i][j] = wc_one;
        setflag[i][j] = 1;
        count++;
      }
    }

    if (count == 0) error->all(FLERR,"Incorrect args for pair coefficients");
  }

  /* ----------------------------------------------------------------------
     init for one type pair i,j and corresponding j,i
     ------------------------------------------------------------------------- */

  double PairCosatt::init_one(int i, int j)
  {
    if (setflag[i][j] == 0) {
      a[i][j] = mix_energy(a[i][i],a[j][j],1.0,1.0);
      r_c[i][j] = mix_distance(r_c[i][i],r_c[j][j]);
      w_c[i][j] = mix_distance(w_c[i][i],w_c[j][j]);
    }

    if (offset_flag) {
      offset[i][j] = 0.0;
    } else offset[i][j] = 0.0;

    a[j][i] = a[i][j];
    r_c[j][i] = r_c[i][j];
    w_c[j][i] = w_c[i][j];
    offset[j][i] = offset[i][j];

    return r_c[i][j]+w_c[i][j];
  }

/* ----------------------------------------------------------------------
   proc 0 writes to restart file
   ------------------------------------------------------------------------- */

void PairCosatt::write_restart(FILE *fp)
{
  write_restart_settings(fp);

  int i,j;
  for (i = 1; i <= atom->ntypes; i++)
    for (j = i; j <= atom->ntypes; j++) {
      fwrite(&setflag[i][j],sizeof(int),1,fp);
      if (setflag[i][j]) {
        fwrite(&a[i][j],sizeof(double),1,fp);
        fwrite(&r_c[i][j],sizeof(double),1,fp);
        fwrite(&w_c[i][j],sizeof(double),1,fp);
      }
    }
}

/* ----------------------------------------------------------------------
   proc 0 reads from restart file, bcasts
   ------------------------------------------------------------------------- */

void PairCosatt::read_restart(FILE *fp)
{
  read_restart_settings(fp);

  allocate();

  int i,j;
  int me = comm->me;
  for (i = 1; i <= atom->ntypes; i++)
    for (j = i; j <= atom->ntypes; j++) {
      if (me == 0) fread(&setflag[i][j],sizeof(int),1,fp);
      MPI_Bcast(&setflag[i][j],1,MPI_INT,0,world);
      if (setflag[i][j]) {
        if (me == 0) {
          fread(&a[i][j],sizeof(double),1,fp);
          fread(&r_c[i][j],sizeof(double),1,fp);
          fread(&w_c[i][j],sizeof(double),1,fp);
        }
        MPI_Bcast(&a[i][j],1,MPI_DOUBLE,0,world);
        MPI_Bcast(&r_c[i][j],1,MPI_DOUBLE,0,world);
        MPI_Bcast(&w_c[i][j],1,MPI_DOUBLE,0,world);
      }
    }
}

/* ----------------------------------------------------------------------
   proc 0 writes to restart file
   ------------------------------------------------------------------------- */

void PairCosatt::write_restart_settings(FILE *fp)
{
  fwrite(&wc_global,sizeof(double),1,fp);
  fwrite(&rc_global,sizeof(double),1,fp);
  fwrite(&offset_flag,sizeof(int),1,fp);
  fwrite(&mix_flag,sizeof(int),1,fp);
}

/* ----------------------------------------------------------------------
   proc 0 reads from restart file, bcasts
   ------------------------------------------------------------------------- */

void PairCosatt::read_restart_settings(FILE *fp)
{
  if (comm->me == 0) {
    fread(&wc_global,sizeof(double),1,fp);
    fread(&rc_global,sizeof(double),1,fp);
    fread(&offset_flag,sizeof(int),1,fp);
    fread(&mix_flag,sizeof(int),1,fp);
  }
  MPI_Bcast(&wc_global,1,MPI_DOUBLE,0,world);
  MPI_Bcast(&rc_global,1,MPI_DOUBLE,0,world);
  MPI_Bcast(&offset_flag,1,MPI_INT,0,world);
  MPI_Bcast(&mix_flag,1,MPI_INT,0,world);
}

/* ----------------------------------------------------------------------
   proc 0 writes to data file
   ------------------------------------------------------------------------- */

void PairCosatt::write_data(FILE *fp)
{
  for (int i = 1; i <= atom->ntypes; i++)
    fprintf(fp,"%d %g\n",i,a[i][i]);
}

/* ----------------------------------------------------------------------
   proc 0 writes all pairs to data file
   ------------------------------------------------------------------------- */

void PairCosatt::write_data_all(FILE *fp)
{
  for (int i = 1; i <= atom->ntypes; i++)
    for (int j = i; j <= atom->ntypes; j++)
      fprintf(fp,"%d %d %g %g %g\n",i,j,a[i][j],r_c[i][j], w_c[i][j]);
}

/* ---------------------------------------------------------------------- */

double PairCosatt::single(int i, int j, int itype, int jtype, double rsq,
    double factor_coul, double factor_lj,
                          double &fforce)
{
    double rinv,r,wcinv,argument,phi, sinn, coss;

    r = sqrt(rsq);

    if (r < r_c[itype][jtype]) {
        fforce = 0.0;             // 0
        phi = - a[itype][jtype];  // - eps
        return factor_lj*phi;
    }
    if(r > r_c[itype][jtype] + w_c[itype][jtype]) {
        fforce = 0.0;             // 0
        phi = 0.0;  // - eps
    }

    rinv = 1.0/r;

    wcinv = 1.0/w_c[itype][jtype];
    argument = MY_PI2*(r-r_c[itype][jtype])*wcinv; // r_c to r_c+w_c is cos^2, else is 0 and -eps
    sincos(argument, &sinn, &coss);

    fforce = - factor_lj*a[itype][jtype]*MY_PI*coss*sinn*wcinv*rinv; // rinv is normalization of vector
    phi = - a[itype][jtype]*coss*coss - offset[itype][jtype];

    return factor_lj*phi;
}
